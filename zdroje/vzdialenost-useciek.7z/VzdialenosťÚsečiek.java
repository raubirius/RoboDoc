
import knižnica.*;

public class VzdialenosťÚsečiek extends GRobot
{
	private VzdialenosťÚsečiek()
	{
		super(400, 400, "Vzdialenosť úsečiek…");
		Svet.zbaľ();
		Svet.vystreď();
		skry();

		new ObsluhaUdalostí()
		{
			int aktívny = 0;

			final Bod body[] = {new Bod(), new Bod(), new Bod(), new Bod()};
			{
				for (Bod bod : body)
				{
					náhodnáPoloha();
					bod.poloha(poloha());
				}
			}

			@Override public void stlačenieTlačidlaMyši()
			{
				if (ÚdajeUdalostí.tlačidloMyši(ĽAVÉ))
				{
					skočNaMyš();
					for (int i = 0; i < body.length; ++i)
						if (bodVKruhu(body[i])) aktívny = i;
					body[aktívny].poloha(ÚdajeUdalostí.polohaMyši());
				}
			}

			@Override public void ťahanieMyšou()
			{
				if (ÚdajeUdalostí.tlačidloMyši(ĽAVÉ))
				{
					body[aktívny].poloha(ÚdajeUdalostí.polohaMyši());
					prekreslenie();
				}
			}

			@Override public void prekreslenie()
			{
				podlaha.vymažGrafiku();

				farba(čierna);
				skočNa(body[0]);
				choďNa(body[1]);
				skočNa(body[2]);
				choďNa(body[3]);

				farba(modrá);
				for (int i = 0; i < body.length; ++i)
				{
					skočNa(body[i]);
					krúžok(3);
				}

				Bod priesečník = Svet.priesečníkÚsečiek(
					body[0], body[1], body[2], body[3]);

				if (priesečník == null)
				{
					Bod najbližší, polohy[] = {body[0],
						Svet.najbližšíBodNaÚsečke(body[0], body[2], body[3])};
					double zmeraná, vzdialenosť =
						Svet.vzdialenosť(polohy[0], polohy[1]);

					najbližší = Svet.najbližšíBodNaÚsečke(
						body[1], body[2], body[3]);
					zmeraná = Svet.vzdialenosť(body[1], najbližší);
					if (zmeraná < vzdialenosť)
					{
						polohy[0] = body[1];
						polohy[1] = najbližší;
						vzdialenosť = zmeraná;
					}

					najbližší = Svet.najbližšíBodNaÚsečke(
						body[2], body[0], body[1]);
					zmeraná = Svet.vzdialenosť(body[2], najbližší);
					if (zmeraná < vzdialenosť)
					{
						polohy[0] = body[2];
						polohy[1] = najbližší;
						vzdialenosť = zmeraná;
					}

					najbližší = Svet.najbližšíBodNaÚsečke(
						body[3], body[0], body[1]);
					zmeraná = Svet.vzdialenosť(body[3], najbližší);
					if (zmeraná < vzdialenosť)
					{
						polohy[0] = body[3];
						polohy[1] = najbližší;
						vzdialenosť = zmeraná;
					}

					farba(zelená);
					skočNa(polohy[0]);
					choďNa(polohy[1]);
				}
				else
				{
					farba(červená);
					skočNa(priesečník);
					krúžok(3);
				}

				double vzdialenosť = Svet.vzdialenosťÚsečiek(
					body[0], body[1], body[2], body[3]);
				skočNa(0, 190);
				text(F(vzdialenosť, 2));
			}
		}.prekreslenie();
	}

	public static void main(String[] args)
	{
		new VzdialenosťÚsečiek();
	}
}
