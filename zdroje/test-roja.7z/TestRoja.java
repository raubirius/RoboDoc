
/**
 * Test používa príkazový riadok na pridávanie jednotlivých konfigurácií
 * bodov roja. Aktuálna konfigurácia bodov a plôch roja je automaticky
 * ukladaná do a čítaná z konfiguračného súboru, čo treba brať do úvahy pri
 * viacnásobných štartoch aplikácie a tiež pri prípadnej definícii
 * konštruktora aplikácie. (Na rýchly reset stavu môže poslúžiť skrátenie
 * alebo vymazanie konfiguračného súboru.)
 * 
 * Tip: Po prvom štrte stlačte Enter, zadajte napríklad tento príkaz
 * (a potvrďte ho):
 * 
 * 		pridaj osemsten
 * 
 */

import knižnica.Roj;
import static knižnica.Svet.*;
import static java.lang.Math.*;

public class TestRoja extends OvládačRoja
{
	private TestRoja() {}


	public void pridajCikcaky()
	{
		// Niekoľko farebných cik-cakov.
		for (int i = -4; i < 5; ++i)
		{
			bod(70, i * 28, i * 28, 25,  tmavočervená);
			bod(70, i * 28, i * 28, 50, svetločervená);
		}

		for (int i = -4; i < 5; ++i)
		{
			bod(i * 28, 70, i * 28, 25,  tmavozelená);
			bod(i * 28, 70, i * 28, 50, svetlozelená);
		}

		for (int i = -4; i < 5; ++i)
		{
			bod(i * 28, i * 28, 70, 25,  tmavomodrá);
			bod(i * 28, i * 28, 70, 50, svetlomodrá);
		}

		for (int i = -4; i < 5; ++i)
		{
			bod(70, i * 28, i * 28, 25,  tmavotyrkysová);
			bod(70, i * 28, i * 28, 50, svetlotyrkysová);
		}

		for (int i = -4; i < 5; ++i)
		{
			bod(i * 28, 70, i * 28, 25,  tmavopurpurová);
			bod(i * 28, 70, i * 28, 50, svetlopurpurová);
		}

		for (int i = -4; i < 5; ++i)
		{
			bod(i * 28, i * 28, 70, 25,  tmavožltá);
			bod(i * 28, i * 28, 70, 50, svetložltá);
		}
	}

	public void pridajKocku()
	{
		// Kocka z bodov 7 × 7 × 7.

		for (double y = -15; y <= 15; y += 5)
		{
			for (double x = -15; x <= 15; x += 5)
			{
				for(double z = -15; z <= 15; z += 5)
				{
					Roj.Bod bod = roj.pridajBod();
					bod.x0 = x;
					bod.y0 = y;
					bod.z0 = z;
				}
			}
		}
	}

	public void pridajZrezanuKocku() { pridajZrezanúKocku(); }
	public void pridajZrezanúKocku()
	{
		// Kocka s vynechanou guľou uprostred.
		// 
		// (Na lepšie vnímanie je tento príklad „zrezaný“ na jednu
		// osminu – do hlavného oktantu priestoru.)
		final int zrež = 3;
		roj.smerník.vkladajSpoje = false;

		for (int i = 3 - zrež; i <= 3; ++i)
		{
			for (int j = 3 - zrež; j <= 3; ++j)
			{
				for (int k = 3 - zrež; k <= 3; ++k)
				{
					if (i * i + j * j + k * k >= 9)
					{
						bod(i * 8, j * 8, k * 8, hnedá);
						// bod(i * 8, j * 8, k * 8, 50, ružová);
						// bod(i * 8, j * 8, k * 8, 80, purpurová);

						if (!roj.smerník.vkladajSpoje)
							roj.smerník.vkladajSpoje = true;
					}
				}

				roj.smerník.vkladajSpoje = false;
			}
		}
	}

	public void pridajSpiralu() { pridajŠpirálu(); }
	public void pridajŠpirálu()
	{
		roj.smerník.vkladajSpoje = false;
		for (int i = 0; i < 100; ++i)
		{
			roj.smerník.otoč(10, 0, 0);
			roj.smerník.posuň(3);
			Roj.Bod bod = roj.smerník.pridajBod();
			bod.farba = červená;
			roj.smerník.posuň(1, 0, 0);
			if (!roj.smerník.vkladajSpoje)
			{
				// bod.zobraz = false;
				roj.smerník.vkladajSpoje = true;
			}
		}
	}

	public void pridajOsemsten()
	{
		final double strana = 25;
		double x1 = 1, y1 = 0, z1 = 0;
		double x2 = 0, y2 = 1, z2 = 0;
		double x3 = 0, y3 = 0, z3 = 1;
		double x4 = -1, y4 = 0, z4 = 0;
		double x5 = 0, y5 = -1, z5 = 0;
		double x6 = 0, y6 = 0, z6 = -1;
		double xn, yn, zn;

		// double[] normála = Roj.normála(x1, y1, z1, x2, y2, z2, x3, y3, z3);

		// // Test normalizácie:
		// System.out.println(normála[0] + "; " + normála[1] + "; " + normála[2]);
		// roj.smerník.smer(normála);
		// Roj.normalizuj(normála);
		// System.out.println(normála[0] + "; " + normála[1] + "; " + normála[2]);
		// normála = roj.smerník.smer();
		// System.out.println(normála[0] + "; " + normála[1] + "; " + normála[2]);
		// normála = new double[] {1, 1};
		// System.out.println(normála[0] + "; " + normála[1]);
		// Roj.normalizuj(normála);
		// System.out.println(normála[0] + "; " + normála[1]);

		Plocha p1 = new Plocha(), p2 = new Plocha(), p3 = new Plocha(),
			p4 = new Plocha(), p5 = new Plocha(), p6 = new Plocha(),
			p7 = new Plocha(), p8 = new Plocha();

		roj.smerník.vkladajObjekty = roj.smerník.vkladajSpoje = false;
		p8.bod1 = p5.bod1 = p4.bod1 = p1.bod1 = bod(x1, y1, z1, strana); // bod 1
		p6.bod1 = p5.bod3 = p2.bod1 = p1.bod2 = bod(x2, y2, z2, strana); // bod 2
		p4.bod2 = p3.bod3 = p2.bod3 = p1.bod3 = bod(x3, y3, z3, strana); // bod 3
		p7.bod1 = p6.bod3 = p3.bod1 = p2.bod2 = bod(x4, y4, z4, strana); // bod 4
		p8.bod2 = p7.bod3 = p4.bod3 = p3.bod2 = bod(x5, y5, z5, strana); // bod 5
		p8.bod3 = p7.bod2 = p6.bod2 = p5.bod2 = bod(x6, y6, z6, strana); // bod 6

		// bod(x1, y1, z1, strana, červená, true, false);

		roj.smerník.vkladajObjekty = true;

		xn = (x1 + x2 + x3) * strana / 3;
		yn = (y1 + y2 + y3) * strana / 3;
		zn = (z1 + z2 + z3) * strana / 3;

		(p1.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p1.polygón;
		p1.kedySkryť = 0; p1.priehľadnosťVýplne = 128; p1.priehľadnosťObrysu = 255;
		// p1.ostrosťTieňov = 42.5;

		// roj.smerník.smer(normála);
		// roj.smerník.posuň(20);
		// Roj.Bod bod = roj.smerník.pridajBod();
		// bod.farba = bod.farbaSpoja = žltá;
		// bod.dho = bod.dh = 2;
		// bod.kreslenie = šípka;

		xn = (x4 + x2 + x3) * strana / 3;
		yn = (y4 + y2 + y3) * strana / 3;
		zn = (z4 + z2 + z3) * strana / 3;

		(p2.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p2.polygón;
		p2.kedySkryť = 0; p2.priehľadnosťVýplne = 128; p2.priehľadnosťObrysu = 255;
		// p2.ostrosťTieňov = 42.5;

		xn = (x4 + x5 + x3) * strana / 3;
		yn = (y4 + y5 + y3) * strana / 3;
		zn = (z4 + z5 + z3) * strana / 3;

		(p3.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p3.polygón;
		p3.kedySkryť = 0; p3.priehľadnosťVýplne = 128; p3.priehľadnosťObrysu = 255;
		// p3.ostrosťTieňov = 42.5;

		xn = (x1 + x5 + x3) * strana / 3;
		yn = (y1 + y5 + y3) * strana / 3;
		zn = (z1 + z5 + z3) * strana / 3;

		(p4.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p4.polygón;
		p4.kedySkryť = 0; p4.priehľadnosťVýplne = 128; p4.priehľadnosťObrysu = 255;
		// p4.ostrosťTieňov = 42.5;

		xn = (x1 + x2 + x6) * strana / 3;
		yn = (y1 + y2 + y6) * strana / 3;
		zn = (z1 + z2 + z6) * strana / 3;

		(p5.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p5.polygón;
		p5.kedySkryť = 0; p5.priehľadnosťVýplne = 128; p5.priehľadnosťObrysu = 255;
		// p5.ostrosťTieňov = 42.5;

		xn = (x4 + x2 + x6) * strana / 3;
		yn = (y4 + y2 + y6) * strana / 3;
		zn = (z4 + z2 + z6) * strana / 3;

		(p6.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p6.polygón;
		p6.kedySkryť = 0; p6.priehľadnosťVýplne = 128; p6.priehľadnosťObrysu = 255;
		// p6.ostrosťTieňov = 42.5;

		xn = (x4 + x5 + x6) * strana / 3;
		yn = (y4 + y5 + y6) * strana / 3;
		zn = (z4 + z5 + z6) * strana / 3;

		(p7.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p7.polygón;
		p7.kedySkryť = 0; p7.priehľadnosťVýplne = 128; p7.priehľadnosťObrysu = 255;
		// p7.ostrosťTieňov = 42.5;

		xn = (x1 + x5 + x6) * strana / 3;
		yn = (y1 + y5 + y6) * strana / 3;
		zn = (z1 + z5 + z6) * strana / 3;

		(p8.stred = bod(xn, yn, zn, tyrkysová)).kreslenie = p8.polygón;
		p8.kedySkryť = 0; p8.priehľadnosťVýplne = 128; p8.priehľadnosťObrysu = 255;
		// p8.ostrosťTieňov = 42.5;
	}

	public void pridajZvlnenuPlochu() { pridajZvlnenúPlochu(); }
	public void pridajZvlnenúPlochu()
	{
		if (ÁNO != otázka("Táto ukážka definuje až 3 600 jednotlivých " +
			"bodov.\nJej vykonaním sa zníži výkon aplikácie pri ukladaní " +
			"a čítaní konfigurácie.\nChcete ju aj tak vykonať?", "Varovanie!"))
			return;

		for (double y = -90; y <= 90; y += 3)
		{
			for (double x = -90; x <= 90; x += 3)
			{
				Roj.Bod bod = roj.pridajBod();
				bod.x0 = x / 2;
				bod.y0 = y / 2;
				bod.z0 =
					// x + y;
					cos(toRadians(x)) *
					sin(toRadians(y)) *
					20.0;
				bod.farba = biela;
				bod.spoj = false;
			}
		}
	}


	public static void main(String[] args)
	{
		použiKonfiguráciu("TestRoja.cfg");
		aktivujHistóriuVstupnéhoRiadka();
		uchovajHistóriuVstupnéhoRiadka();
		new TestRoja().konfigurácia();
	}
}
