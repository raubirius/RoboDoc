
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;

import knižnica.*;

public class TestPrenosuOkna extends GRobot
{
	public interface Akcia { public void vykonaj(); }

	@SuppressWarnings("serial")
	public class InéOkno extends JFrame
	{
		private JFrame hlavnéOkno;

		public void reframe()
		{
			setBounds(hlavnéOkno.getBounds());
		}

		public InéOkno(JFrame hlavnéOkno, Akcia akcia)
		{
			this.hlavnéOkno = hlavnéOkno;
			setIconImage(hlavnéOkno.getIconImage());
			setTitle(hlavnéOkno.getTitle());
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

			addWindowListener(new WindowAdapter()
			{
				@Override public void windowClosing(WindowEvent e)
				{ akcia.vykonaj(); }
			});

			setAlwaysOnTop(true);
			setUndecorated(true);
			setBackground(žiadna);
		}
	}

	private InéOkno inéOkno = null;
	private boolean tam = true;

	private TestPrenosuOkna()
	{
		Svet.farbaPozadia(žiadna);
		Svet.farbaPlochy(žiadna);

		hrúbkaČiary(5);
		veľkosť(150);
		farba(nebeská);
	}

	@Override public void kresliTvar()
	{
		krúžok();
	}

	private void prepniOkno()
	{
		if (null == inéOkno)
			inéOkno = new InéOkno(svet, ()-> prepniOkno());

		if (tam)
		{
			Svet.prenes(inéOkno, true);
			Svet.skry();
			inéOkno.reframe();
			inéOkno.setVisible(true);
			tam = false;
		}
		else
		{
			Svet.prenes(inéOkno, false);
			inéOkno.setVisible(false);
			Svet.zobraz();
			zmenaVeľkostiOkna();
			tam = true;
		}
	}

	@Override public void klik()
	{
		if (ÚdajeUdalostí.tlačidloMyši(ĽAVÉ)) prepniOkno();
	}

	@Override public void tik()
	{
		if (Svet.neboloPrekreslené())
		{
			Svet.resetujRaster();
			Svet.prekresli();
			if (null != inéOkno)
				inéOkno.repaint();
		}
	}

	public static void main(String[] args)
	{
		Svet.skry();
		Svet.použiKonfiguráciu("TestPrenosuOkna.cfg");
		Svet.nekresli();
		new TestPrenosuOkna();
		Svet.zobraz();
		Svet.spustiČasovač();
	}
}
