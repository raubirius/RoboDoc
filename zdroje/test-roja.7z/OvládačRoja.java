
/**
 * Ovládač, ktorý rozširuje (napr.) TestRoja. Ovládač definuje zaujímavý
 * prvok: plochu, ktorá môže reprezentovať elementárny 3D trojuholník
 * (triangle), z ktorého sa vo svete 3D grafiky skladajú ďalšie (zložitejšie)
 * 3D objekty. Ovládač implementuje dve verzie kreslenia: klasický polygón
 * (trojuholník) a elipsu, ktorá má byť ukážkou toho, že sa dá experimentovať
 * aj s inými spôsobmi zobrazenia.
 * 
 * (Poznámka: V roku 1994 bola vydaná hra Ecstatica
 * (https://youtu.be/9SsR5fPjGu4, https://youtu.be/datpiAyu7Os,
 * https://en.wikipedia.org/wiki/Ecstatica), ktorá experimentovala
 * s objektmi zloženými z elipsoidov, pričom jednotlivé elipsoidy boli
 * základnými zobrazovacími prvkami 3D objektov, to jest neboli zložené
 * z menších polygónov ako by to bolo riešené dnes; to by nebolo v tom čase
 * výkonovo možné. Plochá elipsa v našej ukážke však na míle vzdialená od
 * vytieňovaných elipsoidov, s ktorými autori Ecstaticy dosiahli prekvapivé
 * výsledky. V našej ukážke kreslenia elíps ide iba o grafický experiment,
 * ktorý by vyžadoval ďalšie zlepšenia implementujúce kreslenie na úrovni
 * jednotlivých bodov.)
 * 
 * Táto ukážka kreslenia plôch neukazuje dokonalé implementácie. Ide iba
 * o naznačenie ďalších krokov pri vzdelávaní sa v oblasti 3D grafiky. Do
 * tejto úrovne sú to stále elementárne záležitosti, no ďalej v tomto
 * programovacom rámci (a s ním prepojenými ukážkami) nezachádzame.
 */

import static knižnica.Kláves.*;
import static knižnica.Svet.*;
import static knižnica.ÚdajeUdalostí.*;
import static java.lang.Math.*;

import knižnica.Farba;
import knižnica.GRobot;
import knižnica.KreslenieTvaru;
import knižnica.ObsluhaUdalostí;
import knižnica.Roj;
import knižnica.Súbor;
import knižnica.Zoznam;
import java.io.IOException;

public class OvládačRoja extends GRobot
{
	// Konštantný (v reči jazyka Java „finálny“ objekt; poznámka: tento objekt
	// je zároveň aj statický, čo je iný koncept, ale v tomto prípade to dosť
	// úzko súvisí) objekt slúžiaci na označenie všetkých súčastí kreslenia
	// úsečiek v miestach osí súradnicovej sústavy.
	private final static Object súčasťOsi = new Object();

	// Roj ovládača.
	public final Roj roj;

	// Rôzne atribúty súvisiace s ovládaním roja týmto ovládačom:
	public int režim = 1;
	public boolean infoORoji = true;
	public double myšX = 0;
	public double myšY = 0;

	// Atribúty súvisiace s demonštračným otáčaním roja:
	public boolean otáčanie = false;
	public double Δα = 0.0;
	public double Δβ = 0.0;
	public double Δγ = -2.2;

	// Príznak nevyhnutnosti prekreslenia roja:
	private boolean prekresliRoj = true;

	// Uchovanie a obnova základného stavu roja (vypnuté).
	// {{{
	/*
		public class StavRoja
		{
			public double[] uhly = null;
			public double[] stred = null;
			public double[] kamera = null;
			public double mierka = 1000.0;

			public void zálohuj()
			{
				uhly = roj.uhly();
				stred = roj.stredOtáčania();
				kamera = roj.kamera();
				mierka = roj.mierka();
			}

			public void obnov()
			{
				roj.nastavUhly(uhly);
				roj.nastavStredOtáčania(stred);
				roj.nastavKameru(kamera);
				if (null != uhly || null != stred || null != kamera)
					roj.mierka(mierka);
			}
		}

		public class StavBodov
		{
			private final double[] polohy = new double[] {0.0, 0.0, 0.0};
			private final double[] uhly = new double[] {0.0, 0.0, 0.0};

			public void nastav(double[] polohy, double[] uhly)
			{
				if (null != polohy && polohy.length >= 3)
					System.arraycopy(polohy, 0, this.polohy, 0, 3);
				if (null != uhly && uhly.length >= 3)
					System.arraycopy(uhly, 0, this.uhly, 0, 3);
				obnov();
			}

			public void zálohuj()
			{
				for (Roj.Bod bod : roj.body())
					if (1 > bod.skupina || 3 < bod.skupina)
					{
						polohy[0] = bod.dx;
						polohy[1] = bod.dy;
						polohy[2] = bod.dz;
						uhly[0] = bod.alfa;
						uhly[1] = bod.beta;
						uhly[2] = bod.gama;
						return;
					}
			}

			public void obnov()
			{
				polohaBodov(polohy[0], polohy[1], polohy[2]);
				uhlyBodov(uhly[0], uhly[1], uhly[2]);
			}
		}

		public final StavRoja stavRoja = new StavRoja();
		public final StavBodov stavBodov = new StavBodov();

		public void polohaBodov(double x, double y, double z)
		{
			for (Roj.Bod bod : roj.body())
				if (1 > bod.skupina || 3 < bod.skupina)
				{
					bod.dx = x;
					bod.dy = y;
					bod.dz = z;
					bod.transformuj = true;
				}

			roj.transformovať();
			prekresliRoj = true;
		}

		public void uhlyBodov(double α, double β, double γ)
		{
			for (Roj.Bod bod : roj.body())
				if (1 > bod.skupina || 3 < bod.skupina)
				{
					bod.alfa = α;
					bod.beta = β;
					bod.gama = γ;
					bod.transformuj = true;
				}

			roj.transformovať();
			prekresliRoj = true;
		}
	*/
	// }}}


	// 
	// Plochy
	// ------
	// 
	// Poznámka: O plochách je podrobnejšie písané v hlavnom komentári tohto
	// súboru (na začiatku súboru).
	// 


	// Zoznam definovaných plôch.
	private final Zoznam<Plocha> plochy = new Zoznam<Plocha>();

	// Plocha reprezentujúca elementárny 3D trojuholník.
	public class Plocha
	{
		public Plocha() { plochy.pridaj(this); }

		public double ostrosťTieňov = 110.0;
		public int kedySkryť = 1;	// Do úvahy sa berie len znamienko (čiže
									// stačí používať hodnoty -1, 0 a 1).
		public int priehľadnosťVýplne = 255; // 255 – nepriehľadná farba
		public int priehľadnosťObrysu = 0;   // 0 – neviditeľná farba

		public Roj.Bod bod1;
		public Roj.Bod bod2;
		public Roj.Bod bod3;
		public Roj.Bod stred;


		// Plocha má definované dve kreslenia: polygón (trojuholník) a elipsu.
		// Obidve majú spoločné dve veci: spôsob výpočtu toho, kedy prvok
		// skryť a toho, akým odtieňom farby ho nakresliť.
		// 
		// Zobrazenie alebo skrytie (nenakreslenie) sa riadi hodnotou atribútu
		// kedySkryť a normály kresleného tvaru. Ak je atribút kedySkryť
		// nenulový, tak podľa jeho znamienka a znamienka normály objekt
		// nakreslí (resp. nenakreslí).
		// 
		// Odtieň farby je ovplyvňovaný faktorom, ktorý má určovať smer
		// prichádzajúceho ambientného svetla. V tomto príklade je to
		// vyriešené veľmi priamočiaro:
		// 
		// Ak si necháte zobraziť priebeh funkcie 1 − sin α, zistíte, že to
		// je vlastne sínus v protifáze, ktorého „amplitúda“ (obor hodnôt)
		// je posunutá tak, aby nikdy neklesla pod nulu (hodnoty funkcie sa
		// pohybujú len v kladných hodnotách od 0 do 2). No a táto funkcia
		// je použitá na vypočítanie faktora z uhlov orientácie objektu
		// v osiach x, y a atribútu ostrosťTieňov. Je to len veľmi jednoduchý
		// spôsob zmeny odtieňa kreslenia podľa orientácie objektu.
		// (Dokonalejšia implementácia by vyžadovala definíciu svetelného
		// zdroja alebo viacerých zdrojov.)
		// 
		// (Podobných kreslení by sa dalo vymyslieť mnoho.)


		// Kreslenie trojuholníka (pozri vyššie)…
		public KreslenieTvaru polygón = r ->
		{
			boolean zobraziť;

			if (0 == kedySkryť) zobraziť = true; else
			{
				double[] normála = Roj.normála(bod1.x3, bod1.y3, bod1.z3,
					bod2.x3, bod2.y3, bod2.z3, bod3.x3, bod3.y3, bod3.z3);
				zobraziť = signum(kedySkryť) == signum(normála[2]);
			}

			if (zobraziť)
			{
				Farba f = r.farba();

				r.skočNa(bod1.x3, bod1.y3);
				r.začniCestu();
				r.skočNa(bod2.x3, bod2.y3);
				r.skočNa(bod3.x3, bod3.y3);
				r.skončiCestu();

				if (0 < priehľadnosťVýplne)
				{
					double[] uhlyK = Roj.uhlyK(stred.x1, stred.y1, stred.z1);
					double faktor =
						(1 - sin(toRadians(uhlyK[0]))) * ostrosťTieňov +
						(1 - sin(toRadians(uhlyK[1]))) * ostrosťTieňov;

					int odtieň = (int)faktor;
					if (odtieň < 0) odtieň = 0;
					else if (odtieň > 255) odtieň = 255;

					if (priehľadnosťVýplne >= 255)
						r.farba((odtieň + f.getRed()) / 2,
							(odtieň + f.getGreen()) / 2,
							(odtieň + f.getBlue()) / 2);
					else
						r.farba((odtieň + f.getRed()) / 2,
							(odtieň + f.getGreen()) / 2,
							(odtieň + f.getBlue()) / 2,
							priehľadnosťVýplne);
					r.vyplňCestu();
				}

				if (0 < priehľadnosťObrysu)
				{
					if (255 >= priehľadnosťObrysu) r.farba(f);
					else r.farba(f.getRed(), f.getGreen(), f.getBlue(),
						priehľadnosťObrysu);
					r.obkresliCestu();
				}
			}
		};

		// Kreslenie elipsy (pozri vyššie)…
		public KreslenieTvaru elipsa = r ->
		{
			boolean zobraziť;

			if (0 == kedySkryť) zobraziť = true; else
			{
				double[] normála = Roj.normála(bod1.x3, bod1.y3, bod1.z3,
					bod2.x3, bod2.y3, bod2.z3, bod3.x3, bod3.y3, bod3.z3);
				zobraziť = signum(kedySkryť) == signum(normála[2]);
			}

			if (zobraziť)
			{
				Farba f = r.farba();

				r.skočNa(bod1.x3, bod1.y3);
				r.otočNa(bod2.x3, bod2.y3);
				double a = r.vzdialenosťK(bod3.x3, bod3.y3);
				double b = r.vzdialenosťK(bod2.x3, bod2.y3);

				if (0 < priehľadnosťVýplne)
				{
					double[] uhlyK = Roj.uhlyK(stred.x1, stred.y1, stred.z1);
					double faktor =
						(1 - sin(toRadians(uhlyK[0]))) * ostrosťTieňov +
						(1 - sin(toRadians(uhlyK[1]))) * ostrosťTieňov;

					int odtieň = (int)faktor;
					if (odtieň < 0) odtieň = 0;
					else if (odtieň > 255) odtieň = 255;

					if (priehľadnosťVýplne >= 255)
						r.farba((odtieň + f.getRed()) / 2,
							(odtieň + f.getGreen()) / 2,
							(odtieň + f.getBlue()) / 2);
					else
						r.farba((odtieň + f.getRed()) / 2,
							(odtieň + f.getGreen()) / 2,
							(odtieň + f.getBlue()) / 2,
							priehľadnosťVýplne);
					r.vyplňElipsu(a, b);
				}

				if (0 < priehľadnosťObrysu)
				{
					if (255 >= priehľadnosťObrysu) r.farba(f);
					else r.farba(f.getRed(), f.getGreen(), f.getBlue(),
						priehľadnosťObrysu);

					// Nakreslenie poloosí na testovacie účely:
					// posuňVpravo(a); posuňVľavo(a);
					// dopredu(b); dozadu(b);

					r.kresliElipsu(a, b);
				}
			}
		};


		// Prečítanie plochy z konfiguračného súboru.
		public void čítajZoSúboru(Súbor súbor, String identifikátor)
			throws IOException
		{
			súbor.vnorMennýPriestorVlastností(identifikátor);

			try
			{
				ostrosťTieňov = súbor.čítajVlastnosť(
					"ostrosťTieňov", ostrosťTieňov);
				kedySkryť = súbor.čítajVlastnosť(
					"kedySkryť", kedySkryť);
				priehľadnosťVýplne = súbor.čítajVlastnosť(
					"priehľadnosťVýplne", priehľadnosťVýplne);
				priehľadnosťObrysu = súbor.čítajVlastnosť(
					"priehľadnosťObrysu", priehľadnosťObrysu);

				int[] body = súbor.čítajVlastnosť("body", (int[])null);
				if (null != body)
				{
					Zoznam<Roj.Bod> zoznam = roj.body();

					if (body.length > 0) bod1 = zoznam.daj(body[0]);
					if (body.length > 1) bod2 = zoznam.daj(body[1]);
					if (body.length > 2) bod3 = zoznam.daj(body[2]);
					if (body.length > 3) stred = zoznam.daj(body[3]);

					String typ = súbor.čítajVlastnosť("typ", (String)null);
					if (null == typ) typ = "poly"; else
					typ = typ.trim().toLowerCase();

					if (typ.startsWith("poly")) stred.kreslenie = polygón;
					else if (typ.startsWith("elli") || typ.startsWith("elip"))
						stred.kreslenie = elipsa;
				}
			}
			finally
			{
				súbor.vynorMennýPriestorVlastností();
			}
		}

		// Uloženie plochy do konfiguračného súboru.
		public void uložDoSúboru(Súbor súbor, String identifikátor)
			throws IOException
		{
			súbor.vnorMennýPriestorVlastností(identifikátor);

			try
			{
				súbor.zapíšVlastnosť("ostrosťTieňov", ostrosťTieňov);
				súbor.zapíšVlastnosť("kedySkryť", kedySkryť);
				súbor.zapíšVlastnosť("priehľadnosťVýplne", priehľadnosťVýplne);
				súbor.zapíšVlastnosť("priehľadnosťObrysu", priehľadnosťObrysu);

				StringBuffer body = new StringBuffer();
				Zoznam<Roj.Bod> zoznam = roj.body();
				int index = zoznam.indexOf(bod1);
				body.append(index); body.append(" ");
				index = zoznam.indexOf(bod2);
				body.append(index); body.append(" ");
				index = zoznam.indexOf(bod3);
				body.append(index); body.append(" ");
				index = zoznam.indexOf(stred);
				body.append(index); body.append(" ");
				súbor.zapíšVlastnosť("body", body);

				if (stred.kreslenie == polygón)
					súbor.zapíšVlastnosť("typ", "polygón");
				else if (stred.kreslenie == elipsa)
					súbor.zapíšVlastnosť("typ", "elipsa");
			}
			finally
			{
				súbor.vynorMennýPriestorVlastností();
			}
		}
	}


	// Konštruktor.
	public OvládačRoja()
	{
		// Jedine tento riadok nesmie byť v metóde inicializácia (nižšie),
		// pretože finálne premenné musia byť inicializované buď hneď na
		// mieste ich definície, alebo v konštruktore:
		roj = new Roj(this);

		// Zvyšok inicializácie je v samostatnej metóde. Toto riešenie je
		// dobré vtedy, keď chceme mať možnosť „resetu“ stavu aplikácie
		// aj počas jej činnosti (po konštrukcii). Počas implementácie
		// tejto ukážky táto možnosť prestala byť potrebná, takže v tomto
		// prípade je to vlastne už len ukážka tejto možnosti.
		inicializácia();
	}


	// Takmer úplná inicializácia (spomínaná v konštruktore vyššie).
	private void inicializácia()
	{
		// skry();
		nekresli();

		farbaPlochy(245, 255, 250);
		farbaPozadia(245, 250, 255);
		strop.písmo("Cambria", 14);
		strop.farbaTextu(30, 20, 10);

		// osi();
	}

	// Metóda umožňujúca spustenie konfigurácie vo vhodnom čase (pripravené
	// pre triedy, ktoré budú od tejto triedy odvodené). Metóda spúšťa aj
	// časovač.
	public void konfigurácia()
	{
		new ObsluhaUdalostí()
		{
			@Override public boolean konfiguráciaZmenená()
			{ return true; }

			@Override public void zapíšKonfiguráciu(Súbor súbor)
				throws java.io.IOException
			{
				// Pred uložením konfigurácie vymažeme z roja všetky body
				// súvisiace so zobrazovaním úsečiek v mieste osí súradnicovej
				// sústavy (ktoré sme si vopred úmyselne označili na to
				// rezervovaným objektom).
				vymažOsi();

				roj.uložDoSúboru(súbor, null);

				int početPlôch = plochy.veľkosť();
				súbor.zapíšPrázdnyRiadokVlastností();
				súbor.zapíšVlastnosť("početPlôch", početPlôch);

				for (int i = 0; i < početPlôch; ++i)
				{
					súbor.zapíšPrázdnyRiadokVlastností();
					plochy.daj(i).uložDoSúboru(súbor, "plocha[" + i + "]");
				}

				// Zápis zálohovaných stavov (vypnuté).
				// {{{
				/*
					stavRoja.zálohuj();
					stavBodov.zálohuj();

					súbor.zapíšVlastnosť("uhly", stavRoja.uhly);
					súbor.zapíšVlastnosť("stred", stavRoja.stred);
					súbor.zapíšVlastnosť("kamera", stavRoja.kamera);
					súbor.zapíšVlastnosť("mierka", stavRoja.mierka);

					súbor.zapíšVlastnosť("polohyBodov", stavBodov.polohy);
					súbor.zapíšVlastnosť("uhlyBodov", stavBodov.uhly);
				*/
				// }}}
			}

			@Override public void čítajKonfiguráciu(Súbor súbor)
				throws java.io.IOException
			{
				if (null == roj)
				{
					System.err.println(
						"Chyba! Roj ešte nie je inicializovaný…");
					return;
				}

				roj.čítajZoSúboru(súbor, null);

				int početPlôch = súbor.čítajVlastnosť("početPlôch", 0);
				for (int i = 0; i < početPlôch; ++i)
				{
					Plocha plocha = new Plocha();
					plocha.čítajZoSúboru(súbor, "plocha[" + i + "]");
				}

				// Čítanie zálohovaných stavov (vypnuté).
				// {{{
				/*
					stavRoja.zálohuj();
					stavBodov.zálohuj();

					stavRoja.uhly = súbor.čítajVlastnosť(
						"uhly", stavRoja.uhly);
					stavRoja.stred = súbor.čítajVlastnosť(
						"stred", stavRoja.stred);
					stavRoja.kamera = súbor.čítajVlastnosť(
						"kamera", stavRoja.kamera);
					stavRoja.mierka = súbor.čítajVlastnosť(
						"mierka", stavRoja.mierka);

					double[] polohyBodov = súbor.čítajVlastnosť(
						"polohyBodov", stavBodov.polohy);
					double[] uhlyBodov = súbor.čítajVlastnosť(
						"uhlyBodov", stavBodov.uhly);

					stavRoja.obnov();
					stavBodov.nastav(polohyBodov, uhlyBodov);
				*/
				// }}}
			}
		};

		infoORoji();
		spustiČasovač();
	}


	// Metódy na rýchle pridávanie bodov do roja (na ich rýchlejšiu
	// a jednoduchšiu inicializáciu).
	// {{{
		public Roj.Bod bod(double x, double y, double z)
		{
			roj.smerník.poloha(x, y, z);
			return roj.smerník.pridajBod();
		}

		public Roj.Bod bod(double x, double y, double z, double d)
		{
			roj.smerník.poloha(0, 0, 0);
			roj.smerník.smer(x, y, z);
			roj.smerník.posuň(d);
			return roj.smerník.pridajBod();
		}

		public Roj.Bod bod(double x, double y, double z, Farba f)
		{
			roj.smerník.poloha(x, y, z);
			Roj.Bod bod = roj.smerník.pridajBod();
			bod.farba = bod.farbaSpoja = f;
			return bod;
		}

		public Roj.Bod bod(double x, double y, double z, double d, Farba f)
		{
			roj.smerník.poloha(0, 0, 0);
			roj.smerník.smer(x, y, z);
			roj.smerník.posuň(d);
			Roj.Bod bod = roj.smerník.pridajBod();
			bod.farba = bod.farbaSpoja = f;
			return bod;
		}

		public Roj.Bod bod(double x, double y, double z, Farba f,
			boolean spoj, boolean zobraz)
		{
			roj.smerník.poloha(x, y, z);
			Roj.Bod bod = roj.smerník.pridajBod();
			bod.farba = bod.farbaSpoja = f;
			bod.spoj = spoj;
			bod.zobraz = zobraz;
			return bod;
		}

		public Roj.Bod bod(double x, double y, double z, double d, Farba f,
			boolean spoj, boolean zobraz)
		{
			roj.smerník.poloha(0, 0, 0);
			roj.smerník.smer(x, y, z);
			roj.smerník.posuň(d);
			Roj.Bod bod = roj.smerník.pridajBod();
			bod.farba = bod.farbaSpoja = f;
			bod.spoj = spoj;
			bod.zobraz = zobraz;
			return bod;
		}
	// }}}


	// Pomocné nástroje na definíciu, úpravu viditeľnosti a likvidáciu úsečiek
	// v mieste osí súradnicovej sústavy.
	// {{{
		private Roj.Bod osX = null;
		private Roj.Bod osY = null;
		private Roj.Bod osZ = null;

		// Vlastný tvar na kreslenie šípky na konci osi.
		public KreslenieTvaru šípka = r ->
		{
			r.vpravo(18);
			r.vzad(14);
			r.zdvihniPero();
			r.vpred(14);
			r.vľavo(36);
			r.položPero();
			r.vzad(14);
		};

		// Vymazanie všetkých súčastí osí (užitočné pred ukladaním roja do
		// konfigurácie).
		public void vymažOsi()
		{
			// Na identifikáciu súčastí použijeme rezervovaný objekt súčasťOsi.
			for (Roj.Bod bod : roj.body())
				if (bod.objekt == súčasťOsi) roj.vymažBod(bod);
			osX = osY = osZ = null;
		}

		// Definovanie alebo úprava dĺžky osi x.
		public void osX(double dĺžka)
		{
			if (null == osX)
			{
				Roj.Bod bod = roj.pridajBod();
				bod.zobraz = bod.spoj = false;
				bod.x0 = -2;
				bod.skupina = 1;
				bod.objekt = súčasťOsi; // „označenie“ súčasti osi

				osX = roj.pridajBod();
				osX.farba = osX.farbaSpoja = červená;
				osX.x0 = dĺžka;
				osX.skupina = 1;
				osX.kreslenie = šípka;
				osX.objekt = súčasťOsi; // „označenie“ súčasti osi
			}
			else osX.x0 = dĺžka;
			prekresliRoj = true;
		}

		// Zobrazenie/skrytie osi x.
		public void osX(boolean zobraz)
		{
			if (null == osX)
			{
				if (zobraz) osX(70);
				else return;
			}
			osX.zobraz = osX.spoj = zobraz;
			prekresliRoj = true;
		}

		// Overenie, či je os x zobrazená.
		public boolean osX()
		{
			if (null == osX) return false;
			return osX.spoj;
		}

		// Definovanie alebo úprava dĺžky osi y.
		public void osY(double dĺžka)
		{
			if (null == osZ)
			{
				Roj.Bod bod = roj.pridajBod();
				bod.zobraz = bod.spoj = false;
				bod.y0 = -2;
				bod.skupina = 2;
				bod.objekt = súčasťOsi; // „označenie“ súčasti osi

				osY = roj.pridajBod();
				osY.farba = osY.farbaSpoja = zelená;
				osY.y0 = dĺžka;
				osY.skupina = 2;
				osY.kreslenie = šípka;
				osY.objekt = súčasťOsi; // „označenie“ súčasti osi
			}
			else osY.y0 = dĺžka;
			prekresliRoj = true;
		}

		// Zobrazenie/skrytie osi y.
		public void osY(boolean zobraz)
		{
			if (null == osY)
			{
				if (zobraz) osY(70);
				else return;
			}
			osY.zobraz = osY.spoj = zobraz;
			prekresliRoj = true;
		}

		// Overenie, či je os y zobrazená.
		public boolean osY()
		{
			if (null == osY) return false;
			return osY.spoj;
		}

		// Definovanie alebo úprava dĺžky osi z.
		public void osZ(double dĺžka)
		{
			if (null == osZ)
			{
				Roj.Bod bod = roj.pridajBod();
				bod.zobraz = bod.spoj = false;
				bod.z0 = -2;
				bod.skupina = 3;
				bod.objekt = súčasťOsi; // „označenie“ súčasti osi

				osZ = roj.pridajBod();
				osZ.farba = osZ.farbaSpoja = modrá;
				osZ.z0 = dĺžka;
				osZ.skupina = 3;
				osZ.kreslenie = šípka;
				osZ.objekt = súčasťOsi; // „označenie“ súčasti osi
			}
			else osZ.z0 = dĺžka;
			prekresliRoj = true;
		}

		// Zobrazenie/skrytie osi z.
		public void osZ(boolean zobraz)
		{
			if (null == osZ)
			{
				if (zobraz) osZ(70);
				else return;
			}
			osZ.zobraz = osZ.spoj = zobraz;
			prekresliRoj = true;
		}

		// Overenie, či je os z zobrazená.
		public boolean osZ()
		{
			if (null == osZ) return false;
			return osZ.spoj;
		}

		// Definovanie alebo úprava dĺžky všetkých troch osí naraz.
		public void osi(double dĺžkaX, double dĺžkaY, double dĺžkaZ)
		{
			osX(dĺžkaX);
			osY(dĺžkaY);
			osZ(dĺžkaZ);
		}

		// Zobrazenie/skrytie troch osí naraz.
		public void osi(boolean zobraz)
		{
			osX(zobraz);
			osY(zobraz);
			osZ(zobraz);
		}

		// Zobrazenie (definovanie) všetkých troch osí s predvolenými
		// hodnotami dĺžok.
		public void osi() { osi(70, 70, 70); }
	// }}}


	// Hromadné úpravy roja a jeho bodov.
	// {{{
		// Rýchle nastavenie predvolených vlastností roja.
		public void resetujRoj()
		{
			roj.nastavUhly(-110, -360, 45);
			roj.nastavStredOtáčania(0, 0, 0);
			roj.nastavKameru(0, -125, 200);
			roj.mierka(1000);
			prekresliRoj = true;
		}

		// Reset vnútorných individuálnych vlastností posunutia (dx až dz)
		// a pootočenia (alfa až gama) jednotlivých bodov roja.
		public void resetujBody()
		{
			for (Roj.Bod bod : roj.body())
				if (1 > bod.skupina || 3 < bod.skupina)
				{
					bod.dx = bod.dy = bod.dz =
						// bod.xs = bod.ys = bod.zs =
						bod.alfa = bod.beta = bod.gama = 0.0;
					bod.transformuj = true;
				}

			roj.transformovať();
			prekresliRoj = true;
		}

		// Posunutie s pomocou vnútorných vlastností dx až dz bodov roja.
		public void posuňBody(double Δx, double Δy, double Δz)
		{
			for (Roj.Bod bod : roj.body())
				if (1 > bod.skupina || 3 < bod.skupina)
				{
					bod.dx += Δx;
					bod.dy += Δy;
					bod.dz += Δz;
					bod.transformuj = true;
				}

			roj.transformovať();
			prekresliRoj = true;
		}

		// Pootočenie s pomocou vnútorných vlastností alfa až gama bodov roja.
		public void pootočBody(double Δα, double Δβ, double Δγ)
		{
			for (Roj.Bod bod : roj.body())
				if (1 > bod.skupina || 3 < bod.skupina)
				{
					bod.alfa += Δα;
					bod.beta += Δβ;
					bod.gama += Δγ;
					bod.transformuj = true;
				}

			roj.transformovať();
			prekresliRoj = true;
		}
	// }}}


	// Výpis informácií o aktuálnom stave roja (v kontexte tohto ovládača).
	public void infoORoji()
	{
		vymažTexty();

		if (0 != režim && infoORoji)
		{
			vypíšRiadok("K[x, y, z]: ", F(roj.kameraX(), 2), "; ",
				F(roj.kameraY(), 2), "; ", F(roj.kameraZ(), 2));
			vypíšRiadok("SO[x, y, z]: ", F(roj.stredOtáčaniaX(), 2), "; ",
				F(roj.stredOtáčaniaY(), 2), "; ", F(roj.stredOtáčaniaZ(), 2));
			vypíšRiadok("α, β, γ: ", F(roj.uholAlfa(), 2), "°; ",
				F(roj.uholBeta(), 2), "°; ", F(roj.uholGama(), 2), "°");
			vypíšRiadok("M: ", F(roj.mierka(), 2));

			vypíš("Režim myši: ");
			switch (režim)
			{
			case 1: vypíšRiadok("kamera"); break;
			case 2: vypíšRiadok("stred otáčania"); break;
			case 3: vypíšRiadok("uhly rotácie"); break;
			case 4: vypíšRiadok("mierka"); break;
			case 5: vypíšRiadok("posunutie bodov"); break;
			case 6: vypíšRiadok("pootočenie bodov"); break;
			}

			if (otáčanie) vypíšRiadok(riadok, "automatické otáčanie");
		}
	}


	// Reakcie na udalosti súvisiace s ovládaním.
	// {{{
		@Override public void tik()
		{
			if (otáčanie) pootočBody(Δα, Δβ, Δγ);

			if (prekresliRoj)
			{
				prekresliRoj = false;
				vymažGrafiku();
				roj.kresli();
			}

			if (neboloPrekreslené()) prekresli();
		}

		@Override public void uvoľnenieKlávesu()
		{
			switch (kláves())
			{
			case VK_0: režim = 0; break;
			case VK_1: režim = 1; break;
			case VK_2: režim = 2; break;
			case VK_3: režim = 3; break;
			case VK_4: režim = 4; break;
			case VK_5: režim = 5; break;
			case VK_6: režim = 6; break;

			case VK_O: otáčanie = !otáčanie; break;
			case VK_I: infoORoji = !infoORoji; break;
			case VK_S: osi(!osX()); break;

			case VK_ENTER:
				začniVstup();
				break;

			case MEDZERA:
				resetujRoj();
				resetujBody();
				break;
			}

			infoORoji();
		}

		@Override public void potvrdenieÚdajov()
		{
			// Vstupný riadok akceptuje príkazy začínajúce sa slovami
			// „pridaj“ a „osi“ (a tiež samostatný príkaz osi).
			String príkaz = prevezmiReťazec();
			try
			{
				String príkazMalým = príkaz.trim().toLowerCase();
				if (príkazMalým.startsWith("pridaj ") ||
					príkazMalým.startsWith("osi ") ||
					príkazMalým.equals("osi"))
				{
					if (this.vykonajPríkaz(príkaz))
					{
						prekresliRoj = true;
						infoORoji();
					}
					else
						chyba("Príkaz ovládača roja sa nepodarilo vykonať.");
				}
				else
					chyba("Neznámy príkaz ovládača roja.");
			}
			catch (Exception e)
			{
				chyba(e.getMessage());
			}
		}

		@Override public void stlačenieTlačidlaMyši()
		{
			// if (tlačidloMyši(ĽAVÉ)) {} else {}
			myšX = polohaMyšiX();
			myšY = polohaMyšiY();
		}

		@Override public void ťahanieMyšou()
		{
			if (tlačidloMyši(ĽAVÉ))
			{
				switch (režim)
				{
				case 1:
					roj.posuňKameru(polohaMyšiX() - myšX,
						polohaMyšiY() - myšY, 0.0);
					break;

				case 2:
					roj.posuňStredOtáčania(polohaMyšiX() - myšX,
						polohaMyšiY() - myšY, 0.0);
					break;

				case 3:
					if (myš().isControlDown())
					{
						if (myš().isShiftDown())
							roj.pootoč(0.0, (polohaMyšiX() - myšX +
								polohaMyšiY() - myšY) / 10.0, 0.0);
						else
							roj.pootoč((polohaMyšiX() - myšX +
								polohaMyšiY() - myšY) / 10.0, 0.0, 0.0);
					}
					else
						roj.pootoč((polohaMyšiY() - myšY) / 10.0,
							(polohaMyšiX() - myšX) / 10.0, 0.0);
					break;

				case 4:
					roj.zmeňMierku((myšX - polohaMyšiX()) / 10.0 +
						(myšY - polohaMyšiY()) / 1.0);
					break;

				case 5:
					posuňBody((polohaMyšiX() - myšX) / 10.0,
						(myšY - polohaMyšiY()) / 10.0, 0);
					break;

				case 6:
					pootočBody((polohaMyšiY() - myšY) / 10.0,
						(polohaMyšiX() - myšX) / 10.0, 0);
					break;
				}
			}
			else
			{
				switch (režim)
				{
				case 1:
					roj.posuňKameru(0.0, 0.0,
						((myšX - polohaMyšiX()) / 100.0) +
						((myšY - polohaMyšiY()) / 10.0));
					break;

				case 2:
					roj.posuňStredOtáčania(0.0, 0.0,
						myšY - polohaMyšiY());
					break;

				case 3:
					roj.pootoč(0.0, 0.0, (polohaMyšiX() - myšX +
						polohaMyšiY() - myšY) / 10.0);
					break;

				case 4:
					roj.zmeňMierku((myšX - polohaMyšiX()) / 1000.0 +
						(myšY - polohaMyšiY()) / 100.0);
					break;

				case 5:
					posuňBody(0, 0, (polohaMyšiX() - myšX) / 100.0 +
						(polohaMyšiY() - myšY) / 10.0);
					break;

				case 6:
					pootočBody(0, 0, (polohaMyšiX() - myšX +
						polohaMyšiY() - myšY) / 10.0);
					break;
				}
			}

			myšX = polohaMyšiX();
			myšY = polohaMyšiY();

			prekresliRoj = true;
			infoORoji();
		}
	// }}}


	// Kreslenie vlastného tvaru robota, ktoré je predvoleným tvarom
	// tých bodov roja, ktoré nemajú definovaný žiadny vlastný tvar.
	// (V tomto príklade sú to všetky body roja, okrem úsečiek osí,
	// ktoré majú definovaný koncový tvar šípky.)
	@Override public void kresliTvar()
	{
		hrúbkaČiary(veľkosť() / 10.0);
		Farba f = farba();

		int odtieň = (int)((veľkosť() + 5.0) * 10.0);
		if (odtieň < 0) odtieň = 0;
		else if (odtieň > 255) odtieň = 255;

		farba(
			(odtieň + f.getRed())   / 2,
			(odtieň + f.getGreen()) / 2,
			(odtieň + f.getBlue())  / 2);
		kruh();

		farba(f);
		kružnica();
	}


	// Pôvodná hlavná metóda na testovacie účely.
	/*public static void main(String[] args)
	{
		použiKonfiguráciu("OvládačRoja.cfg");
		aktivujHistóriuVstupnéhoRiadka();
		uchovajHistóriuVstupnéhoRiadka();
		new OvládačRoja().konfigurácia();
	}*/
}
